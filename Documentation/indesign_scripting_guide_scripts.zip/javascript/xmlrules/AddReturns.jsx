﻿//AddReturns.jsx
//An InDesign CS4 JavaScript
//
//Adds a return character between each XML element.
//You must copy the file "glue code.jsx" from the XML Rules folder (inside the Scripts
//folder inside your InDesign folder) to the folder containing this script, or provide a full
//path to the file in the next line.
#include "glue code.jsx";
main();
function main(){
    mySetup();
    mySnippet();
    myTeardown();
}
function mySetup(){
}
function mySnippet(){
    //<fragment>
	if (app.documents.length != 0){
		var myDocument = app.documents.item(0); 
		//This rule set contains a single rule.
		var myRuleSet = new Array (new AddReturns);
		with(myDocument){
			var elements = xmlElements;
			__processRuleSet(elements.item(0), myRuleSet);
		}
	}
	else{
		alert("No open document");
	}
    //</fragment>
}
function myTeardown(){
}
//<fragment>
function AddReturns(){
    //Adds a return character at the end of every XML element.
    this.name = "AddReturns";
    //XPath will match on every XML element in the XML structure.
    this.xpath = "//*";	
    // Define the apply function.
    this.apply = function(myElement, myRuleProcessor){
        with(myElement){
            //Add a return character after the end of the XML element
            //(this means that the return does not become part of the
            //XML element data, but becomes text data associated with the
            //parent XML element).
            insertTextAsContent("\r", XMLElementPosition.afterElement);
            //To add the return at the end of the element, use:
            //insertTextAsContent("\r", LocationOptions.atEnd);
        }
        return true;
    }
}
//</fragment>