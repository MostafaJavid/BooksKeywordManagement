﻿//DuplicateXMLElement.jsx
//An InDesign CS4 JavaScript
// 
//You must copy the file "glue code.jsx" from the XML Rules folder (inside the Scripts
//folder inside your InDesign folder) to the folder containing this script, or provide a full
//path to the file in the next line.
#include "glue code.jsx";
main();
function main(){
    mySetup();
    mySnippet();
    myTeardown();
}
function mySetup(){
}
function mySnippet(){
    //<fragment>
	if (app.documents.length != 0){
		var myDocument = app.documents.item(0); 
		//This rule set contains a single rule.
		var myRuleSet = new Array (new DuplicateElement);
		with(myDocument){
			var elements = xmlElements;
			__processRuleSet(elements.item(0), myRuleSet);
		}
	}
	else{
		alert("No open document");
	}
    //</fragment>
}
function myTeardown(){
}
//<fragment>
//Duplicates the part number element in each XML element.
function DuplicateElement(){
    this.name = "DuplicateElement";
    this.xpath = "/devices/device/part_number";	
    this.apply = function(myElement, myRuleProcessor){
        //Duplicates the part_number XML element.
        __skipChildren(myRuleProcessor);
        myElement.duplicate();
        return true;
    }
}
//</fragment>