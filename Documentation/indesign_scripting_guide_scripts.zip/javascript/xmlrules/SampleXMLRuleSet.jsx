﻿//SampleXMLRuleSet.jsx
//An InDesign CS4 JavaScript
//
//A Sample XML Rule Set
//<fragment>
var myRuleSet = new Array (new SortByName,
							new AddStaticText,
							new LayoutElements,
							new FormatElements
							);
//</fragment>
