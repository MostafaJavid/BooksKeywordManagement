var myEventListener = app.eventListeners.add("beforeOpen", function()
	{
		alert("Got to here!");
		//var myEvents = app.documents.item(0).events;
		//$.write(myEvents.length + "\r");	
	}
);