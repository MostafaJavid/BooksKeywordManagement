myReadXMLPreferences();
var myButtonName, myButtonType, myButtonFileName, myButtonIconFile;
for(var myCounter = 0; myCounter < myButtons.length(); myCounter++){
	myButtonName = myButtons[myCounter].xpath("buttonName");
	myButtonType = myButtons[myCounter].xpath("buttonType");
	myButtonFileName = myButtons[myCounter].xpath("buttonFileName");
	myButtonIconFile = myButtons[myCounter].xpath("buttonIconFile");
}
function myReadXMLPreferences(){
	myXMLFile = File.openDialog("Choose the file containing your button bar defaults");
	var myResult = myXMLFile.open("r", undefined, undefined);
	var myButtons = "";
	if(myResult == true){
		var myXMLDefaults = myXMLFile.read();
		myXMLFile.close();
		var myXMLDefaults = new XML(myXMLDefaults);
		var myButtons = myXMLDefaults.xpath("/buttons/button");
	}
	return myButtons;
}