﻿//MoveTextBetweenDocuments.jsx
//An InDesign CS4 JavaScript
//
//Moves formatted text from one document to another using import/export.
main();
function main(){
    mySetup();
    mySnippet();
    myTeardown();
}
function mySetup(){
	var myDocument = app.documents.add();
	var myPage = app.activeWindow.activePage;
	var myTextFrame = myPage.textFrames.add({geometricBounds:myGetBounds(myDocument, myPage), contents:"This is the source text.\rThis text is not the source text."});
	myTextFrame.parentStory.paragraphs.item(0).pointSize = 24;
}
function mySnippet(){
	//<fragment>
	var mySourceDocument = app.documents.item(0);
	var mySourcePage = myDocument.pages.item(0);
	var mySourceTextFrame = mySourcePage.textFrames.item(0);
	//Create a new document to move the text to.
	var myTargetDocument = app.documents.add();
	var myTargetPage = app.activeWindow.activePage;
	//Create a text frame in the target document.
	var myTargetTextFrame = myTargetPage.textFrames.add({geometricBounds:myGetBounds(myTargetDocument, myTargetDocument.pages.item(0)), contents:"This is the target text. Insert the source text after this paragraph.\r"});
	//Move the text from the first document to the second. This deletes
	//the text from the first document.
	mySourceTextFrame.parentStory.paragraphs.item(0).move(LocationOptions.atBeginning, myTargetTextFrame.insertionPoints.item(0));
	//To duplicate (rather than move) the text, use the following:
	//myTextFrame.parentStory.paragraphs.item(0).duplicate(LocationOptions.atBeginning, myTargetTextFrame.insertionPoints.item(0));
	//</fragment>
}
function myTeardown(){
}
function myGetBounds(myDocument, myPage){
	var myPageWidth = myDocument.documentPreferences.pageWidth;
	var myPageHeight = myDocument.documentPreferences.pageHeight
	if(myPage.side == PageSideOptions.leftHand){
		var myX2 = myPage.marginPreferences.left;
		var myX1 = myPage.marginPreferences.right;
	}
	else{
		var myX1 = myPage.marginPreferences.left;
		var myX2 = myPage.marginPreferences.right;
	}
	var myY1 = myPage.marginPreferences.top;
	var myX2 = myPageWidth - myX2;
	var myY2 = myPageHeight - myPage.marginPreferences.bottom;
	return [myY1, myX1, myY2, myX2];
}