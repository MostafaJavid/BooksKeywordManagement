﻿//TextExportPreferences.jsx
//An InDesign CS4 JavaScript
//
//Sets the text export filter preferences.
main();
function main(){
    mySetup();
    mySnippet();
    myTeardown();
}
function mySetup(){
}
function mySnippet(){
	//<fragment>
	with(app.textExportPreferences){
		//Options for characterSet:
		//TextExportCharacterSet.unicode
		//TextExportCharacterSet.defaultPlatform
		characterSet = TextExportCharacterSet.unicode;
		//platform options:
		//ImportPlatform.macintosh
		//ImportPlatform.pc
		platform = ImportPlatform.macintosh;
	}
	//</fragment>
}
function myTeardown(){
}
