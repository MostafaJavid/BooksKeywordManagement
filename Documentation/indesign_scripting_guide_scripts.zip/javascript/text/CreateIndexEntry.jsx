//CreateIndexEntry.jsx
//An InDesign CS2 JavaScript
//
//Shows how to create an index, create a topic, create subtopics, and add page references.
main();
function main(){
	var myFoundItem;
	var myIndexTerm = "Widget";
	//Reset find/change preferences.
	app.findPreferences = NothingEnum.nothing;
	app.changePreferences = NothingEnum.nothing;
	//Make an example document.
	var myDocument = myCreateExampleDocument();
	var myIndex = myDocument.indexes.add(0);
	var myTopic = myIndex.topics.add(myIndexTerm);
	var mySubtopicA = myTopic.topics.add("A");
	var mySubtopicB = myTopic.topics.add("B");
	var mySubtopicC = myTopic.topics.add("C");
	var myFoundItems = myDocument.search("Widget ^?");
	for(var myCounter = myFoundItems.length-1; myCounter >= 0; myCounter --){
		myFoundItem = myFoundItems[myCounter];
		switch(myFoundItem.characters.item(-1).contents){
			case "A":
				mySubtopicA.pageReferences.add(myFoundItem);
				break;
			case "B":
				mySubtopicB.pageReferences.add(myFoundItem);
				break;
			case "C":
				mySubtopicC.pageReferences.add(myFoundItem);
				break;
		}
	}
	//Reset find preferences.
	app.findPreferences = NothingEnum.nothing;
}
function myCreateExampleDocument(){
	var myString = "If you're looking for something to buy, you might consider our Widget A (Part Number: X1234-431, $24.95), "
	myString += "or Widget B (Part Number: X1-4, $74.95).\r";
	myString += "Other options include Widget C (Part Number: X123-43, $135.95) and ";
	myString += "Widget D (Part Number: X12345-4321, $5.95).\r";
	//Create an example document.
	var myDocument = app.documents.add();
	//Create a text frame on page 1.
	var myTextFrame = myDocument.pages.item(0).textFrames.add();
	//Set the bounds of the text frame.
	myTextFrame.geometricBounds = myGetBounds(myDocument, myDocument.pages.item(0));
	//Fill the text frame with example text.
	myTextFrame.contents = myString;
	return myDocument;
}
function myGetBounds(myDocument, myPage){
	var myPageWidth = myDocument.documentPreferences.pageWidth;
	var myPageHeight = myDocument.documentPreferences.pageHeight
	if(myPage.side == PageSideOptions.leftHand){
		var myX2 = myPage.marginPreferences.left;
		var myX1 = myPage.marginPreferences.right;
	}
	else{
		var myX1 = myPage.marginPreferences.left;
		var myX2 = myPage.marginPreferences.right;
	}
	var myY1 = myPage.marginPreferences.top;
	var myX2 = myPageWidth - myX2;
	var myY2 = myPageHeight - myPage.marginPreferences.bottom;
	return [myY1, myX1, myY2, myX2];
}