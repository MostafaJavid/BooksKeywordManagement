﻿//Reframe.jsx
//An InDesign CS4 JavaScript
//
//Shows how to use the reframe method.
main();
function main(){
	mySetup();
	mySnippet();
	myTeardown();
}
function mySetup(){
	var myDocument = app.documents.add();
	var myPage = myDocument.pages.item(0);
	myDocument.viewPreferences.horizontalMeasurementUnits = MeasurementUnits.points;
	myDocument.viewPreferences.verticalMeasurementUnits = MeasurementUnits.points;
	var myRectangle = myPage.rectangles.add({geometricBounds:[72, 72, 144, 144], strokeWeight:4});
	var myTransformationMatrix = app.transformationMatrices.add({counterclockwiseRotationAngle:30});
	myRectangle.transform(CoordinateSpaces.pasteboardCoordinates, AnchorPoint.centerAnchor, myTransformationMatrix);	
}
function mySnippet(){
	//PageItem.reframe (in:any, opposingCorners:Array of any) 
	//Move the bounding box of the page item
	//in: Data Type: any 
	//The bounding box to resize. Can accept: CoordinateSpaces enumerator or Ordered array containing coordinateSpace:CoordinateSpaces enumerator, boundsKind:BoundingBoxLimits enumerator.
	//opposingCorners: Data Type: Array of any 
	//Opposing corners of new bounding box in the given coordinate space
	var myRectangle = app.documents.item(0).pages.item(0).rectangles.item(0);	
	//<fragment>
	//Given a reference to a rectangle "myRectangle"...
	var myBounds = myRectangle.geometricBounds;
	var myX1 = myBounds[1]-72;
	var myY1 = myBounds[0]-72;
	var myX2 = myBounds[3]+72;
	var myY2 = myBounds[2]+72;
	var myDuplicate = myRectangle.duplicate();
	myDuplicate.reframe(CoordinateSpaces.innerCoordinates, [[myY1, myX1], [myY2, myX2]]);
	//</fragment>
}
function myTeardown(){
}
