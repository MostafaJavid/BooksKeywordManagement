//Targeting.jsx
//An InDesign CS4 JavaScript
//
//Target the script to a particular version of InDesign

//<fragment>
//Target InDesign CS4
#target "InDesign-6.0"
//Target the latest version of InDesign
#target "InDesign" 
//</fragment>

dummy();

function dummy(){
    alert("Not a stand-alone script. Exists to provide sample code for documentation.");
}
