//ExportPDFWithPreset.jsx
//An InDesign CS4 JavaScript
//
//Shows how to export as PDF using a given PDF export preset.
main();

function main(){
    mySetup();
    mySnippet();
    myTeardown();
}

//<setup>
function mySetup(){
	app.documents.add();
}
//</setup>

//<snippet>
function mySnippet(){
	//<fragment>
	var myDocument = app.documents.item(0);
	//The document.export parameters are:
	//Format as (use either the ExportFormat.pdfType enumeration
	//or the string "Adobe PDF")
	//To as File
	//ShowingOptions as boolean (setting this option to true displays the 
	//PDF Export dialog box)
	//Using as PDF export preset (or a string that is the name of a 
	//PDF export preset)
	//The default PDF export preset names are surrounded by square breackets
	//(e.g., "[High Quality Print], [Press Quality], or [Smallest File Size]").
	var myPDFExportPreset = app.pdfExportPresets.item("[Press Quality]");
	myDocument.exportFile(
		ExportFormat.pdfType,
		File(Folder.desktop + "/ExportPDFWithPreset.pdf"),
		false, 
		myPDFExportPreset
	);
    //</fragment>
}
//</snippet>

//<teardown>
function myTeardown(){
}
//</teardown>

 
